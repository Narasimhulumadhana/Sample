function verifyotp(o1,o2)
{
	var otp1=o1;
	var otp2=o2;
	
	 var saveData = $.ajax({
      url: "http://192.168.0.162:8906/Mployerr/Otpverify",
      type: "POST",
	   dataType:"text",
      data: {
      mobileotp:otp1,
	  emailotp:otp2,
	  
        },
		 success: function(response){
       console.log(response);
	  
	     var myObj1 =jQuery.parseJSON(response);
	   if(myObj1.error)
	   {
		   alert("Invalid otp");
	   }
       else
		{
			alert("otp varrified");
			$.mobile.changePage( "#login ", { transition: "slidedown", changeHash: false }); 
		}
  
}
});
}