function  chck_login(u,p)
{
	var un1=u;
	var pw2=p;
	
	 var saveData = $.ajax({
      url: "http://192.168.0.162:8906/Mployerr/login",
      type: "POST",
	  dataType:"text",
      data: {
      
	  email:un1,
	  pwd:pw2,
	
	  
        },
		 success: function(response){
          console.log(response);
	  
	     var myObj =jQuery.parseJSON(response);
	   if(myObj.error)
	   {
		   alert("login Unsucessful");
	   }
       else
		{
			alert("login sucessful"); 
			$.mobile.changePage( "#details page", { transition: "slidedown", changeHash: false }); 
		}
  
}
});
}