function checkRegistration(fane,lname,uname,pwd1,pwd2,email,number,type){
 
 var fN = fane;
  var LN = lname;
  var UN = uname;
  var PW1 = pwd1;
  var PW2 = pwd2;
  var eMail = email;
  var pnumber = number;
  var type = type;

  
     var saveData = $.ajax({
      url: "http://192.168.0.162:8906/Mployerr/Registration",
      type: "POST",
	   dataType:"text",
      data: {
       firstname: fN,
       lastname: LN,
       username:UN,
       pwd1:PW1,
       pwd2:PW2,
       Email:email,
       number:number,
       type:type,
        },
      success: function(response){
       console.log(response);
	  
	     var myObj =jQuery.parseJSON(response);
	   if(myObj.error)
	   {
		   alert("Your mobile number or email alredy exist");
	   }
       else
		{
			alert("registration success");
			
			$.mobile.changePage( "#otp page", { transition: "slidedown", changeHash: false }); 
		}
  
    }
});
 
}