//page show function for bill payment page
jQuery('#billPayment').on('pageshow', function () {
                     
                     $('#mobileNo').val('');
                     $('#cardNo').val('');
                     $('#cvvNo').val('');
                     $('#amount').val('');
                     $('#cardNo1').val('');
                     $('#cardNo2').val('');
                     $('#cardNo3').val('');
                      $('#cardNo4').val('');
                     $('#serviceProvider').val('1');
                     
                     var serviceProvider = $('select#serviceProvider');
                     serviceProvider[0].selectedIndex = 0;
                     serviceProvider.selectmenu("refresh");
                     
                     var card = $('select#card');
                     card[0].selectedIndex = 0;
                     card.selectmenu("refresh");
            
            });

//Login function with null check validation
function login(){
  
    if( $('#uname').val() == "" || $('#uname').val() == "undefined" || $('#uname').val() == null){
        alert("Please enter the username");
    }else if($('#password').val() == "" || $('#password').val() == "undefined" || $('#password').val() == null){
        alert("Please enter the password");
    }else{
        /* $.mobile.changePage( "#billPayment", { transition: "slidedown", changeHash: false }); */
      var uval1 = $('#uname').val();
        var pval1 = $('#password').val(); 
		 chck_login(uval1,pval1); 
		
    }
  
}
function register()
{
	var fval=$('#firstname').val();
	var lval=$('#lastname').val();
	var emailv=$('#email').val();
	var usernm = $('#username').val();
    var pwd1v = $('#pwd1').val();
	var pwd2v = $('#pwd2').val();
	var numv = $('#number').val();
	var typev=$('#type').val();
	 var email_p = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	 var  pwd_p= /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,15}$/;
	  var mob_p=/^([0-9]{10})/;
	 
   

	
    if( fval == "" || fval == "undefined" || fval== null){
         alert("Error: name cannot be blank!");
		
	}
	 else if( lval == "" || fval == "undefined" || fval== null){
         alert("Error: name cannot be blank!");
		
	}
   else if( emailv== "" || emailv == "undefined" || emailv== null){
        alert("Please enter the Email");
    
	}
	else if (!email_p.test(emailv)) {
    alert('Please provide a valid email address');

       }
	   
    else if( numv == "" ||  numv== null){
         alert("Error: Enter Your 10 Digit Mobile Number!");
	}
		else if (!mob_p.test(numv)) {
       alert("Error:Enter valid Mobile Number");

       }
	
	
	   
    else if(usernm == "" || usernm == "undefined" || usernm == null){
        alert("Please enter the username");
    
	}
	else if(usernm.length <"6"||usernm.length>"20"){
		alert("username must contain 6 to 20 charecters");
	}
	   
	else if(pwd1v == "" || pwd1v== "undefined" ||pwd1v == null){
        alert("Please enter the password");
    }
	else if(pwd1v.length <"6" ){
		alert("password must contain atlest 6 charecters");
	}
	else if(!pwd_p.test(pwd1v))
	{
		 alert("Error: Passwords must contain at least six characters including uppercase, lowercase letters and numbers and special charecters.");
	}
	else  if(pwd2v == "") { 	
        	alert("Reenter password please!");
    
        }
	else if (pwd1v != pwd2v) {
            alert("Passwords Do not match");
        }
		else if($('#type').val() == "" || $('#type').val() == "undefined" || $('#type').val() == null || $('#type').val() == "0"){
        alert("Please select Registering As.");
	}
	
	 else{
		var fnm=$('#firstname').val();
	   var lnm=$('#lastname').val();
	   var email1=$('#email').val();
	   var usernm1 = $('#username').val();
       var pwd11 = $('#pwd1').val();
	   var pwd21 = $('#pwd2').val();
	  var numv1 = $('#number').val();
	  var typev1=$('#type').val();
		 
		 checkRegistration(fnm,lnm,usernm1,pwd11,pwd21,email1,numv1,typev1);
		 
		 
         /* $.mobile.changePage( "#otp page", { transition: "slidedown", changeHash: false });  */
   
    }
    
	
}
function otpvarify()
  {
	  var otpv1 = $('#mobile_otp').val();
	   var otpv2 = $('#email_otp').val();
    if(otpv1 == ""|| otpv2=="") {
      alert("Error:plz enter otp!");
    
    }
    
    else{
		var potp=$('#mobile_otp').val();
		var eotp=$('#email_otp').val();
		 
	
		var saveData = $.ajax({
      url: "http://192.168.0.162:8906/Mployerr/Otpverify",
      type: "POST",
	   dataType:"text",
      data: {
      mobileotp:potp,
	  emailotp:eotp,
	  
        },
		 success: function(response){
       console.log(response);
	  
	     var myObj1 =jQuery.parseJSON(response);
	   if(myObj1.error)
	   {
		   alert("Invalid otp");
	   }
       else
		{
			alert("otp varrified");
			$.mobile.changePage( "#login ", { transition: "slidedown", changeHash: false }); 
		}
  
}
});
		
		
		 /* $.mobile.changePage( "#login", { transition: "slidedown", changeHash: false }); */
	}
	
  }

//Logout function
function logout(){
    $.mobile.changePage( "#login", { transition: "slidedown", changeHash: false });
}

//payment function with all input field validations
function payment(){
    
    var mobilenoval = $('#mobileNo').val();
    var cardno1val = $('#cardNo1').val();
    var cardno2val = $('#cardNo2').val();
    var cardno3val = $('#cardNo3').val();
    var cardno4val = $('#cardNo4').val();
    var cvvnoval = $('#cvvNo').val();
    
    if( $('#mobileNo').val() == "" || $('#mobileNo').val() == "undefined" || $('#mobileNo').val() == null){
        alert("Please enter the mobile number.");
    }
    else if(mobilenoval.length != "10"){
        alert("Please enter a valid mobile number.");
    }
    else if($('#serviceProvider').val() == "" || $('#serviceProvider').val() == "undefined" || $('#serviceProvider').val() == null ||  $('#serviceProvider').val() == "1"){
        alert("Please enter the service provider.");
    }else if($('#amount').val() == "" || $('#amount').val() == "undefined" || $('#amount').val() == null){
        alert("Please enter the amount.");
    }else if($('#card').val() == "" || $('#card').val() == "undefined" || $('#card').val() == null || $('#card').val() == "1"){
        alert("Please select the card type.");
    }else if($('#cardNo1').val() == "" || $('#cardNo1').val() == "undefined" || $('#cardNo1').val() == null){
        alert("Please enter the card number.");
    }
    else if($('#cardNo2').val() == "" || $('#cardNo2').val() == "undefined" || $('#cardNo2').val() == null){
        alert("Please enter the card number.");
    }
    else if($('#cardNo3').val() == "" || $('#cardNo3').val() == "undefined" || $('#cardNo3').val() == null){
        alert("Please enter the card number.");
    }
    else if($('#cardNo4').val() == "" || $('#cardNo4').val() == "undefined" || $('#cardNo4').val() == null){
        alert("Please enter the card number.");
    }
    else if(cardno1val.length != "4" ){
        alert("Please enter a valid card number.");
    }
    else if(cardno2val.length != "4" ){
        alert("Please enter a valid card number.");
    }
    else if(cardno3val.length != "4" ){
        alert("Please enter a valid card number.");
    }
    else if(cardno4val.length != "4" ){
        alert("Please enter a valid card number.");
    }
    else if($('#cvvNo').val() == "" || $('#cvvNo').val() == "undefined" || $('#cvvNo').val() == null){
        alert("Please enter the cvv number");
    }
    else if(cvvnoval.length != "3" ){
        alert("Please enter a valid cvv number.");
    }
    else{
           //ajax call http://54.169.170.177/payment/bills
        var MobileNumber = $('#mobileNo').val();
        //alert(MobileNumber);
        var NetworkSerivceProvider = $('#serviceProvider option:selected').text();
        //alert(NetworkSerivceProvider);
        var Amount = $('#amount').val();
        //alert(Amount);
        var CardType = $('#card option:selected').text();
        //alert(CardType);
        var CardNumber = $('#cardNo1').val()+"-"+$('#cardNo2').val()+"-"+$('#cardNo3').val()+"-"+$('#cardNo4').val();
        //alert(CardNumber);
        var CVV = $('#cvvNo').val();
        //alert(CVV);
        
        var data =  JSON.stringify({
                                   "Operator": {
                                   "Mobile Number": MobileNumber ,
                                   "Network Serivce Provider": NetworkSerivceProvider
                                   },
                                   "Cards": { 
                                   "Amount": Amount,
                                   "Card Type": CardType,
                                   "Card Number": CardNumber,
                                   "CVV": CVV
                                   } 
                                   
                                   });
        console.log("data===>"+data);
        //alert("data"+data);
        $.LoadingOverlay("show");
        
        // Hide it after 3 seconds
        setTimeout(function(){
                   $.LoadingOverlay("hide");
                   $.mobile.changePage( "#PaymentSuccess", { transition: "slidedown", changeHash: false });

                   }, 3000);
        
//        var saveData = $.ajax({
//                              type: 'POST',
//                              url: "http://54.169.170.177/payment/bills",
//                              data: data,
//                              
//                              headers: {
//                              'apic-subs-key':'dd94dba6752e7587',
//                              'Content-Type':'application/json'
//                              
//                              },
//                              success: function(resultData)
//                                {
//                              if(resultData.status == "200"){
//                                  $.mobile.changePage( "#PaymentSuccess", { transition: "slidedown", changeHash: false });
//                                  }
//                                }
//                              });
//        saveData.error(function() {
//                       
//                      //alert("Something went wrong");
//                      $.mobile.changePage( "#PaymentSuccess", { transition: "slidedown", changeHash: false });
//
//                       });
        
    }
}

//Function for page redirection after successful payment 
function paymentSuccess(){    
   $.mobile.changePage( "#billPayment", { transition: "slidedown", changeHash: false});
}
