package com;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONObject;
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();  
		int status=1;
		String fname=request.getParameter("firstname");  
		String lname=request.getParameter("lastname");
		String username=request.getParameter("username");
		String pwd=request.getParameter("pwd1");  
		String email=request.getParameter("Email");  
		String rpwd=request.getParameter("pwd2");
		String number=request.getParameter("number");
		String type=request.getParameter("type");          
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mployer","root","Mployer@11"); 
		
		PreparedStatement ps=con.prepareStatement("select * from users"); 
		ResultSet rs=ps.executeQuery();
		JSONObject json = new JSONObject();
		while(rs.next()) {
			if(pwd.equals(rpwd)) {
			}else {
				json.put("pwd", "password not matched");
				status=0;
			}
			if(rs.getString(5).equals(number)){
				json.put("tel","mobile number already exists");
				status=0;
			}
			if(rs.getString(4).equals(email)){
				json.put("email","email already exists");
				status=0;
			}
			if(rs.getString(8).equals(username)){
				json.put("username","username already exists try another one");
				status=0;
			}

		}
		if(status==0) {
			json.put("error", true);
			out.println(json);
		}else {		
		PreparedStatement ps1=con.prepareStatement("insert into users(firstname,lastname,Email,number,username,pwd,type) values(?,?,?,?,?,?,?)");  	 
		ps1.setString(1,fname);  
		ps1.setString(2,lname);  
		ps1.setString(3,email); 
		ps1.setString(4,number);  
		ps1.setString(5,username); 
		ps1.setString(6,pwd); 
		ps1.setString(7,type); 	          
		int i=ps1.executeUpdate();  
		if(i>0){
			HttpSession session=request.getSession();
			session.setAttribute("email", email);
			json.put("success", true);			
				
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/MobileSms?number="+number);
		rd.include(request, response);  
		//RequestDispatcher rd1 = getServletContext().getRequestDispatcher("/verify?email="+email);
		//rd1.include(request, response);
		out.print(json); 
		}else {
			json.put("error", true);
			out.print(json); 			
		}
		}
		}catch (Exception e2) {
			System.out.println(e2.getMessage());
			}  	          	
		out.close();  
		}
}