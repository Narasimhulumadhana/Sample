package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONObject;

@WebServlet("/Details")
public class Details extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); 
		 HttpSession session=request.getSession(false);  
	    String email=(String)session.getAttribute("email");  
	    System.out.println(email);
		PrintWriter out = response.getWriter();  
		String aadhar=request.getParameter("adhar");
		String gender=request.getParameter("gender");
		String country=request.getParameter("country");  
		String State=request.getParameter("State");
		String city=request.getParameter("prefered_location");
		String ug=request.getParameter("degree");  
		String dept=request.getParameter("dept");  
		String year=request.getParameter("year");  
		String pg=request.getParameter("pg");
		String pdept=request.getParameter("pdept");
		String pyear=request.getParameter("pyear");
		String exp=request.getParameter("exp");  
		try{  
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mployer","root","Mployer@11");
			if(con!=null) {
				out.println("connected");
			PreparedStatement ps=con.prepareStatement("select id from users where Email=?");
			ps.setString(1,email);
			ResultSet rs=ps.executeQuery();
			rs.absolute(1);
			int n=rs.getInt("id");			
			session.setAttribute("id", n);
			PreparedStatement ps1=con.prepareStatement("insert into details(detailsid,aadhar,country,state,city,ug,dept,year,pg,pdept,pyear,exp,gender) values(?,?,?,?,?,?,?,?,?,?,?,?,?)");  
			ps1.setInt(1, n);
			ps1.setString(2,aadhar);
			ps1.setString(3,country);  
			ps1.setString(4,State);  
			ps1.setString(5,city); 
			ps1.setString(6,ug); 
			ps1.setString(7,dept); 
			ps1.setString(8,year); 
			ps1.setString(9,pg); 
			ps1.setString(10,pdept); 
			ps1.setString(11,pyear); 
			ps1.setString(12,exp); 
			ps1.setString(13,gender);
			          
			int i=ps1.executeUpdate();  
			if(i>0){
				
			out.print("You are updated  details...");  	  
			}
			}else {
				out.println("db not connected");
			}
			}catch (Exception e2) {
				System.out.println(e2);
				}  	 	
			out.close();  		
	}
	}
