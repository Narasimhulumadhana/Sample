package com;

import java.io.IOException;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;

@WebServlet("/RetrieveImg")
public class RetrieveImg extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
		        try{
		            Class.forName("com.mysql.jdbc.Driver");
		            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mployer","root","Mployer@11");
		            String realPath = getServletContext().getRealPath("/");
		            File file=new File(realPath+"/resources\\");
		            FileOutputStream fos=new FileOutputStream(file);
		            byte b[];
		            Blob blob;
		            
		            PreparedStatement ps=con.prepareStatement("select * from imaget where id=12"); 
		            ResultSet rs=ps.executeQuery();	           
		            while(rs.next()){
		                blob=rs.getBlob("photo");
		                b=blob.getBytes(1,(int)blob.length());
		                fos.write(b);
		                System.out.print(file);
		            }		            
		            ps.close();
		            fos.close();
		            con.close();
		        }catch(Exception e){
		            e.printStackTrace();
		        }
	}

}
