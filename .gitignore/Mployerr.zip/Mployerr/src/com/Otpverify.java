package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;

@WebServlet("/Otpverify")
public class Otpverify extends HttpServlet {
	private static final long serialVersionUID = 1L;	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		JSONObject json = new JSONObject();
		HttpSession session=request.getSession(false);
		String otp="OTP is veirfied";
		String otp1="Enter valid Otp";
		String str1=request.getParameter("mobileotp");		
		String str2=request.getParameter("emailotp");		
		int str3=(int)session.getAttribute("mobileotp");	
		String mobile=String.valueOf(str3);
		System.out.println(mobile);
		//int str4=(int)session.getAttribute("emailotp");
		//String email=String.valueOf(str4);
		if(str1.equals(mobile)) {
			try {
				json.put("mobile", otp);
				session.removeAttribute("mobileotp");
			} catch (JSONException e) {
				e.printStackTrace();
			}			
		}else {
			try {
				json.put("mobile",otp1 );
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}/*
		if(str2.equals(email)) {
			try {
				json.put("email", otp);
				session.removeAttribute("emailotp");
			} catch (JSONException e) {			
				e.printStackTrace();
			}
		}else {
			try {
				json.put("email", otp1);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}*/
		System.out.println(json);
	}
}
