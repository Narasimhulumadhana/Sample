package com;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.code.facebookapi.FacebookException;
import com.google.code.facebookapi.FacebookJsonRestClient;
import com.google.code.facebookapi.IFacebookRestClient;

@WebServlet("/New")
public class New extends HttpServlet {
private static final long serialVersionUID = 1L;
private String API_KEY="1c36b59974ca90e4cefaa1f5c8e18edf";
private String SECRET_KEY="77f2d4df446ac8ae8b35b008da3d6070";

public void init(ServletConfig config) throws ServletException {
    // TODO Auto-generated method stub

      IFacebookRestClient client = new FacebookJsonRestClient(API_KEY, SECRET_KEY);

            try {
                String token = client.auth_createToken();
                String url = "http://www.facebook.com/login.php?api_key=" + API_KEY
                        + "&v=1.0" + "&auth_token=" + token;
                System.out.println(url);
                Runtime.getRuntime().exec("explorer \"" + url + "\""); 

                System.out.println("Use browser to login then press return");
                System.in.read();

                String session = client.auth_getSession(token);
                System.out.println("Session key is " + session);

                client.friends_get();

            } catch (FacebookException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

}
}
