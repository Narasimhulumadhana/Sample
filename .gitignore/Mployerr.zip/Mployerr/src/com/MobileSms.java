package com;
import java.io.IOException;
import java.net.*;
import java.util.Random;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/MobileSms")
public class MobileSms extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		  
		   HttpSession session=request.getSession();
		   Random rand = new Random();
		   int mobile = 100000 + rand.nextInt(900000);
		   String num=request.getParameter("number");
		   String username="Mployer";
		   String pwd="C0rp@321";
		   int n=mobile;
		   String text="yourotpis:"+n;
		        URL url;
		        try {		        			            
		            String a="http://bhashsms.com/api/sendmsg.php?user="+username+"&pass="+pwd+"&sender=MPLOER&phone="+num+"&text="+text+"&priority=ndnd&stype=normal";
		            url = new URL(a);
		            URLConnection conn = url.openConnection();
		            BufferedReader br = new BufferedReader(
		                               new InputStreamReader(conn.getInputStream()));

		            String inputLine;
		            while ((inputLine = br.readLine()) != null) {
		                    System.out.println(inputLine);
		            }
		            br.close();
		            session.setAttribute("mobileotp", n);
		            System.out.println(n);
		            System.out.println("Done");

		        } catch (MalformedURLException e) {
		            e.printStackTrace();
		        } catch (IOException e) {
		            e.printStackTrace();
		        }

		}
}
