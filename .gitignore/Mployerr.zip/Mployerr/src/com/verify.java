package com;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@WebServlet("/verify")
public class verify extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		Random rand = new Random();	
		HttpSession session=request.getSession(true);
		int mail = 100000 + rand.nextInt(900000);
		String username = "no-reply@mployer.in";
		String password = "%$#Mployer@11";
		String email=request.getParameter("email");
		int n = mail;
		String result = null;
		try {
		     
		    Properties props = System.getProperties();
		    props.setProperty("mail.transport.protocol", "smtp");
		    props.setProperty("mail.host", "in164.fastwebhost.com");
		    props.put("mail.smtp.auth", "true");
		    props.put("mail.smtp.port", "465");
		    props.put("mail.debug", "true");
		    props.put("mail.smtp.socketFactory.port", "465");
		    props.put("mail.smtp.socketFactory.class",
		            "javax.net.ssl.SSLSocketFactory");
		    props.put("mail.smtp.socketFactory.fallback", "false");

		    Session emailSession = Session.getInstance(props,
		            new javax.mail.Authenticator() {
		                protected PasswordAuthentication getPasswordAuthentication() {
		                return new PasswordAuthentication(username,password);
		            }
		    });

		    emailSession.setDebug(true);
		    Message message = new MimeMessage(emailSession);
		    message.setFrom(new InternetAddress(username));
		    message.setRecipients(Message.RecipientType.TO,
		            InternetAddress.parse(email));
		    message.setSubject("Verification of email");
		    message.setText("Your OTP for Corp academia is:"+n);

		    Transport transport = emailSession.getTransport("smtps");
		    transport.connect("in164.fastwebhost.com", username, password);
		    transport.sendMessage(message, message.getAllRecipients());

		    result = "Successfully sent email";
		    session.setAttribute("emailotp", n);
		    System.out.println(result);

		   } catch (MessagingException e) {
			 result = "Unable to send email";
			 System.out.println(result);
		}
		
	}

}
