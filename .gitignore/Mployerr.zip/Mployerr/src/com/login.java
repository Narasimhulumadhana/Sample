package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;

@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html"); 
		response.setContentType("application/json");
		JSONObject json=new JSONObject();		
		PrintWriter out = response.getWriter();
		String email=request.getParameter("email");
		String password=request.getParameter("pwd");
		if(email==null || email.isEmpty()) {
			try {
				json.put("error", "please enter email id");
			} catch (JSONException e) {
				e.printStackTrace();
			}
			out.println(json);
		}else if(password==null || password.isEmpty()) {
			try {
				json.put("error", "please enter password");
			} catch (JSONException e) {
				e.printStackTrace();
			}
			out.println(json);
		}else {
		HttpSession session=request.getSession();
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mployer","root","Mployer@11");  
			PreparedStatement ps=con.prepareStatement("select id from users where Email=? and pwd=?"); 
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet i=ps.executeQuery();	
			if(i.next()) {
				int id=i.getInt("id");				
				json.put("login", "login successfull");
				out.println(json);
				session.setAttribute("id", id);
			}
			else {
				//PreparedStatement ps1=con.prepareStatement("select  from users where Email=?"); 
				json.put("error", "invalid credentials");
				out.println(json);
			}
		}catch (Exception e2) {
			System.out.println(e2);
			} 
		}
	}
}
